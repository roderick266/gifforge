"""gifforge: forge looping GIFs from math."""
__version__ = "0.1.0"
