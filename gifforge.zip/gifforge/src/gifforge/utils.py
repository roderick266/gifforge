from __future__ import annotations

from pathlib import Path

from PIL import Image


def save_gif(frames: list[Image.Image], path: str | Path, fps: int = 25) -> Path:
    """Write frames to a looping GIF and return the path."""
    if not frames:
        raise ValueError("no frames to save")
    path = Path(path)
    frames[0].save(
        path,
        save_all=True,
        append_images=frames[1:],
        duration=max(1, 1000 // fps),
        loop=0,
        optimize=True,
    )
    return path
