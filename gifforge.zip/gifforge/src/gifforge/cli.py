from __future__ import annotations

import argparse
import sys

from gifforge import __version__
from gifforge.effects import EFFECTS
from gifforge.utils import save_gif


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="gifforge", description="Forge looping GIFs from math.")
    p.add_argument("--version", action="version", version=f"gifforge {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="show available effects")

    mk = sub.add_parser("make", help="render an effect to a GIF")
    mk.add_argument("effect", choices=sorted(EFFECTS))
    mk.add_argument("-o", "--output", help="output path (default: <effect>.gif)")
    mk.add_argument("--size", type=int, default=320, help="width/height in px (default 320)")
    mk.add_argument("--frames", type=int, help="number of frames (default: per effect)")
    mk.add_argument("--fps", type=int, default=25, help="playback speed (default 25)")
    mk.add_argument("--seed", type=int, default=7, help="random seed")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.cmd == "list":
        for name in sorted(EFFECTS):
            print(name)
        return 0

    if args.size < 32:
        print("error: --size must be at least 32", file=sys.stderr)
        return 2

    print(f"rendering {args.effect}...")
    frames = EFFECTS[args.effect](size=args.size, frames=args.frames, seed=args.seed)
    out = save_gif(frames, args.output or f"{args.effect}.gif", fps=args.fps)
    print(f"saved {out} ({len(frames)} frames)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
