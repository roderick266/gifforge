"""Effect registry. To add one, write a module with render() and list it here."""
from gifforge.effects import mandelbrot, matrix, spirograph

EFFECTS = {
    "spirograph": spirograph.render,
    "mandelbrot": mandelbrot.render,
    "matrix": matrix.render,
}
