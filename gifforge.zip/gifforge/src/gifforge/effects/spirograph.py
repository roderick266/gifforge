from __future__ import annotations

import colorsys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

POINTS = 1200


def render(size: int = 320, frames: int | None = None, seed: int = 7) -> list[Image.Image]:
    """Two spinning circles added together, with a rainbow running along the line."""
    frames = frames or 60
    t = np.linspace(0, 12 * np.pi, POINTS)
    out = []

    for n in range(frames):
        phase = 2 * np.pi * n / frames
        x = 0.55 * np.cos(t) + 0.3 * np.cos(5.2 * t + phase)
        y = 0.55 * np.sin(t) + 0.3 * np.sin(5.2 * t + phase)
        px = (x * 0.78 + 1) * size / 2
        py = (y * 0.78 + 1) * size / 2

        img = Image.new("RGB", (size, size), (8, 8, 20))
        d = ImageDraw.Draw(img)
        for i in range(POINTS - 1):
            hue = (i / POINTS + n / frames) % 1
            col = tuple(int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.85, 1))
            d.line([(px[i], py[i]), (px[i + 1], py[i + 1])], fill=col, width=2)

        glow = img.filter(ImageFilter.GaussianBlur(max(1, size // 90)))
        img = Image.blend(img, glow, 0.45)
        out.append(img.point(lambda v: min(255, int(v * 1.25))))

    return out
