from __future__ import annotations

import numpy as np
from PIL import Image

# seahorse valley, a nice spot to dive into
CX, CY = -0.743643887037151, 0.131825904205330
TOTAL_ZOOM = 6000


def _escape_counts(zoom: float, size: int, iters: int):
    scale = 1.6 / zoom
    xs = np.linspace(CX - scale, CX + scale, size)
    ys = np.linspace(CY - scale, CY + scale, size)
    c = xs[None, :] + 1j * ys[:, None]
    z = np.zeros_like(c)
    count = np.zeros(c.shape)
    alive = np.ones(c.shape, dtype=bool)

    for i in range(iters):
        z[alive] = z[alive] ** 2 + c[alive]
        gone = alive & (np.abs(z) > 4)
        # smooth coloring, no banding
        count[gone] = i + 1 - np.log(np.log(np.abs(z[gone]))) / np.log(2)
        alive &= ~gone

    return count, alive


def _colorize(count, alive) -> Image.Image:
    t = np.log(count + 1) * 2.5
    rgb = np.stack(
        [0.5 + 0.5 * np.sin(t + shift) for shift in (0.0, 0.9, 2.2)], axis=-1
    )
    img = rgb * 255
    img[alive] = 0
    return Image.fromarray(img.astype(np.uint8))


def render(size: int = 300, frames: int | None = None, seed: int = 7) -> list[Image.Image]:
    """Smooth exponential zoom from the full set down to ~6000x."""
    frames = frames or 100
    step = TOTAL_ZOOM ** (1 / max(1, frames - 1))
    out = []
    for n in range(frames):
        iters = int(100 + 220 * n / max(1, frames - 1))
        count, alive = _escape_counts(step ** n, size, iters)
        out.append(_colorize(count, alive))
    return out
