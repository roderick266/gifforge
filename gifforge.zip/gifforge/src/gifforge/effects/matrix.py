from __future__ import annotations

import random

from PIL import Image, ImageDraw, ImageFont

CHARS = "01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%&*+=<>?/\\|"
FONT_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    "DejaVuSansMono.ttf",
    "Menlo.ttc",
    "consola.ttf",
    "Courier New.ttf",
]


def _load_font(px: int):
    for path in FONT_PATHS:
        try:
            return ImageFont.truetype(path, px)
        except OSError:
            continue
    return ImageFont.load_default()


def render(size: int = 320, frames: int | None = None, seed: int = 7) -> list[Image.Image]:
    """Falling green glyphs. Default frame count loops seamlessly."""
    rng = random.Random(seed)
    cw = max(6, size // 36)
    ch = int(cw * 1.35)
    cols, rows = size // cw, size // ch
    trail = max(4, rows * 2 // 3)
    period = rows + trail
    frames = frames or period * 2
    font = _load_font(max(6, cw + 2))

    glyphs = [[[rng.choice(CHARS) for _ in range(5)] for _ in range(cols)] for _ in range(rows)]
    start = [rng.randrange(period) for _ in range(cols)]
    speed = [rng.choice([1, 1, 2]) for _ in range(cols)]

    out = []
    for n in range(frames):
        img = Image.new("RGB", (size, size), (0, 0, 0))
        d = ImageDraw.Draw(img)
        for c in range(cols):
            head = (start[c] + speed[c] * n) % period
            for r in range(rows):
                dist = (head - r) % period
                if dist >= trail:
                    continue
                b = 1 - dist / trail
                if dist == 0:
                    col = (210, 255, 220)
                else:
                    col = (0, int(255 * b ** 1.5), int(50 * b))
                d.text((c * cw, r * ch), glyphs[r][c][(n // 4 + r) % 5], font=font, fill=col)
        out.append(img)
    return out
