import sys

from gifforge.cli import main

sys.exit(main())
