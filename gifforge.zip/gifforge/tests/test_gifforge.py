import pytest
from PIL import Image

from gifforge.cli import main
from gifforge.effects import EFFECTS
from gifforge.utils import save_gif


@pytest.mark.parametrize("name", sorted(EFFECTS))
def test_effect_renders_expected_frames(name):
    frames = EFFECTS[name](size=64, frames=3, seed=1)
    assert len(frames) == 3
    assert all(f.size == (64, 64) for f in frames)


def test_matrix_default_loop_length_is_deterministic():
    a = EFFECTS["matrix"](size=64, seed=3)
    b = EFFECTS["matrix"](size=64, seed=3)
    assert len(a) == len(b)
    assert a[0].tobytes() == b[0].tobytes()


def test_save_gif_writes_animated_file(tmp_path):
    frames = EFFECTS["spirograph"](size=64, frames=4)
    out = save_gif(frames, tmp_path / "x.gif")
    with Image.open(out) as im:
        assert im.n_frames == 4


def test_save_gif_rejects_empty(tmp_path):
    with pytest.raises(ValueError):
        save_gif([], tmp_path / "x.gif")


def test_cli_list(capsys):
    assert main(["list"]) == 0
    out = capsys.readouterr().out
    assert "spirograph" in out and "mandelbrot" in out and "matrix" in out


def test_cli_make(tmp_path):
    target = tmp_path / "out.gif"
    code = main(["make", "spirograph", "-o", str(target), "--size", "64", "--frames", "3"])
    assert code == 0 and target.exists()


def test_cli_rejects_tiny_size(tmp_path):
    assert main(["make", "matrix", "-o", str(tmp_path / "a.gif"), "--size", "8"]) == 2
