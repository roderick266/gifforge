# gifforge

A tiny Python CLI that forges looping animated GIFs from pure math. No video tools, no heavy dependencies: just Pillow and NumPy.

| Spirograph | Mandelbrot zoom | Matrix rain |
|:---:|:---:|:---:|
| ![spirograph](assets/spirograph.gif) | ![mandelbrot](assets/mandelbrot.gif) | ![matrix](assets/matrix.gif) |

## Install

```bash
git clone <your-repo-url>
cd gifforge
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

## Usage

```bash
gifforge list                               # see available effects
gifforge make spirograph                    # -> spirograph.gif
gifforge make mandelbrot --size 400 --fps 30
gifforge make matrix -o rain.gif --seed 42
```

| Option | Meaning | Default |
|---|---|---|
| `-o, --output` | output file | `<effect>.gif` |
| `--size` | width and height in px | 320 |
| `--frames` | frame count | per effect |
| `--fps` | playback speed | 25 |
| `--seed` | random seed (matrix) | 7 |

You can also run it as a module: `python -m gifforge make matrix`.

## How the effects work

- **spirograph**: two circles spinning at different speeds are added together. The hue shifts along the line and a blur pass adds the glow.
- **mandelbrot**: each frame is an escape-time render with smooth coloring, zoomed exponentially into seahorse valley (about 6000x).
- **matrix**: columns of falling glyphs with a white head and a fading green trail. The default frame count loops seamlessly.

## Project layout

```
src/gifforge/
  cli.py            argparse CLI
  utils.py          save_gif helper
  effects/          one module per effect + registry in __init__.py
tests/              pytest suite
assets/             sample GIFs used in this README
```

## Add your own effect

1. Create `src/gifforge/effects/myeffect.py` with `render(size, frames, seed) -> list[PIL.Image]`.
2. Register it in `src/gifforge/effects/__init__.py`.
3. Run `gifforge make myeffect`.

## Tests

```bash
pytest
```

## Ideas for next

- Particle simulation effect
- `--palette` option for custom colors
- `--loop-check` to verify the last frame lines up with the first
- Publish to PyPI
